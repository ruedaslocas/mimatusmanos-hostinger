import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, Clock } from "lucide-react";
import { useServices } from "@/hooks/useServices";
import { useServicePrices } from "@/hooks/useServicePrices";
import { useSiteContent } from "@/hooks/useSiteContent";
import manicureImage from "@/assets/manicure-service.jpg";
import pedicureImage from "@/assets/pedicure-service.jpg";
import eyebrowImage from "@/assets/eyebrow-service.jpg";

const Servicios = () => {
  const { services, loading } = useServices();
  const { prices } = useServicePrices();
  const { getContent } = useSiteContent();

  const telefono = getContent('telefono', '+34 622 298 109');

  // Mapear las imágenes por categoría
  const categoryImages: Record<string, string> = {
    manicura: manicureImage,
    pedicura: pedicureImage,
    depilacion: eyebrowImage,
    tratamientos: manicureImage
  };

  // Agrupar servicios activos por categoría
  const servicesByCategory = services
    .filter(service => service.is_active)
    .reduce((acc, service) => {
      const category = service.category || 'otros';
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(service);
      return acc;
    }, {} as Record<string, typeof services>);

  // Obtener precios de un servicio
  const getServicePrices = (serviceId: string) => {
    return prices.filter(price => price.service_id === serviceId && price.is_active);
  };

  // Formatear precio
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'EUR'
    }).format(price);
  };

  // Obtener etiqueta de categoría
  const getCategoryLabel = (category: string) => {
    const labels: Record<string, string> = {
      manicura: 'Manos',
      pedicura: 'Pies',
      depilacion: 'Depilación',
      tratamientos: 'Tratamientos'
    };
    return labels[category] || category;
  };

  if (loading) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Cargando servicios...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Header Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-6">
            Nuestros Servicios
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Ofrecemos una amplia gama de servicios de belleza y estética, siempre con 
            los más altos estándares de calidad y profesionalidad.
          </p>
        </div>
      </section>

      {/* Services Categories */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          {Object.entries(servicesByCategory).length === 0 ? (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">No hay servicios disponibles en este momento.</p>
            </div>
          ) : (
            Object.entries(servicesByCategory).map(([category, categoryServices], categoryIndex) => (
              <div key={category} className="mb-20 last:mb-0">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                  <div className={categoryIndex % 2 === 1 ? "order-2" : ""}>
                    <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                      <img 
                        src={categoryImages[category] || manicureImage}
                        alt={`Servicios de ${getCategoryLabel(category)}`}
                        className="w-full h-96 object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                      <div className="absolute bottom-6 left-6">
                        <Badge variant="secondary" className="text-lg px-4 py-2 font-semibold">
                          {getCategoryLabel(category)}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className={categoryIndex % 2 === 1 ? "order-1" : ""}>
                    <div className="space-y-6">
                      <h2 className="text-3xl font-heading font-bold text-primary mb-8">
                        Servicios de {getCategoryLabel(category)}
                      </h2>
                      
                      {categoryServices.map((service) => {
                        const servicePrices = getServicePrices(service.id);
                        
                        return (
                          <Card key={service.id} className="border-l-4 border-l-primary">
                            <CardHeader className="pb-3">
                              <div className="flex justify-between items-start">
                                <div className="flex-1">
                                  <CardTitle className="text-lg font-heading mb-1">
                                    {service.name}
                                  </CardTitle>
                                  {service.duration_minutes && (
                                    <div className="flex items-center text-sm text-muted-foreground">
                                      <Clock className="h-4 w-4 mr-1" />
                                      {service.duration_minutes} min
                                    </div>
                                  )}
                                </div>
                                <div className="flex flex-col gap-1">
                                  {servicePrices.length > 0 ? (
                                    servicePrices.map((price) => (
                                      <Badge key={price.id} variant="outline" className="text-sm font-bold">
                                        {price.price_type !== 'base' && `${price.price_type}: `}
                                        {formatPrice(price.price)}
                                      </Badge>
                                    ))
                                  ) : (
                                    <Badge variant="outline" className="text-sm">
                                      Consultar
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </CardHeader>
                            <CardContent>
                              <p className="text-muted-foreground">
                                {service.description || 'Servicio profesional de alta calidad.'}
                              </p>
                              {servicePrices.length > 1 && (
                                <div className="mt-3 space-y-1">
                                  {servicePrices.map((price) => (
                                    price.description && (
                                      <p key={price.id} className="text-xs text-muted-foreground">
                                        <span className="font-medium capitalize">{price.price_type}:</span> {price.description}
                                      </p>
                                    )
                                  ))}
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">
            ¿Tienes alguna pregunta sobre nuestros servicios?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Nuestro equipo estará encantado de asesorarte y ayudarte a elegir 
            el tratamiento perfecto para ti.
          </p>
          <Button
            variant="secondary"
            size="lg"
            className="text-lg px-8 py-4"
            onClick={() => window.open(`tel:${telefono}`, "_self")}
          >
            <Phone className="h-5 w-5 mr-2" />
            Llamar y consultar
          </Button>
        </div>
      </section>
    </Layout>
  );
};

export default Servicios;