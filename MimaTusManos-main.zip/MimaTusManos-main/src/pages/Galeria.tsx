import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronUp, Image } from "lucide-react";
import Layout from "@/components/Layout";
import { useCategories } from "@/hooks/useCategories";
import { useCategoryPhotos } from "@/hooks/useCategoryPhotos";

const CategoryPhotoGrid = ({ categoryId, categoryName }: { categoryId: string; categoryName: string }) => {
  const { photos, loading } = useCategoryPhotos(categoryId);
  const [showAll, setShowAll] = useState(false);
  
  const displayedPhotos = showAll ? photos : photos.slice(0, 4);
  const hasMore = photos.length > 4;

  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="aspect-square bg-muted animate-pulse rounded-lg" />
        ))}
      </div>
    );
  }

  if (photos.length === 0) {
    return (
      <div className="text-center py-8">
        <Image className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
        <p className="text-muted-foreground">No hay fotos en esta categoría</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {displayedPhotos.map((photo) => (
          <div key={photo.id} className="aspect-square rounded-lg overflow-hidden bg-muted group cursor-pointer">
            <img
              src={photo.photo_url}
              alt={photo.photo_name}
              className="w-full h-full object-cover transition-transform group-hover:scale-105"
            />
          </div>
        ))}
      </div>
      
      {hasMore && (
        <div className="text-center">
          <Button
            variant="outline"
            onClick={() => setShowAll(!showAll)}
            className="flex items-center gap-2"
          >
            {showAll ? (
              <>
                <ChevronUp className="h-4 w-4" />
                Ver menos
              </>
            ) : (
              <>
                <ChevronDown className="h-4 w-4" />
                Ver más ({photos.length - 4} fotos adicionales)
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
};

const Galeria = () => {
  const { categories, loading } = useCategories();
  
  const activeCategories = categories.filter(category => category.is_active);

  if (loading) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Cargando galería...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Galería de Trabajos
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Descubre nuestros trabajos organizados por categorías. 
            Cada imagen refleja nuestro compromiso con la belleza y el cuidado personal.
          </p>
        </div>

        {/* Categories */}
        <div className="space-y-12">
          {activeCategories.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Image className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-2xl font-semibold mb-2">Galería en construcción</h3>
                <p className="text-muted-foreground">
                  Estamos preparando nuestra galería con los mejores trabajos. 
                  ¡Pronto podrás ver todas nuestras creaciones!
                </p>
              </CardContent>
            </Card>
          ) : (
            activeCategories.map((category) => (
              <Card key={category.id} className="overflow-hidden">
                <CardHeader className="bg-muted/50">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle className="text-2xl flex items-center gap-3">
                        {category.name}
                        <Badge variant="secondary">
                          {category.description || "Categoría"}
                        </Badge>
                      </CardTitle>
                      {category.description && (
                        <p className="text-muted-foreground mt-2">
                          {category.description}
                        </p>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <CategoryPhotoGrid 
                    categoryId={category.id} 
                    categoryName={category.name}
                  />
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold text-foreground mb-4">
                ¿Te gusta lo que ves?
              </h2>
              <p className="text-muted-foreground text-lg mb-6 max-w-2xl mx-auto">
                Reserva tu cita y déjanos cuidar de ti. Nuestro equipo está listo para 
                ofrecerte la mejor experiencia en belleza y cuidado personal.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="cta" size="lg" className="flex items-center gap-2">
                  <Image className="h-5 w-5" />
                  Ver Servicios
                </Button>
                <Button variant="outline" size="lg">
                  Contactar Ahora
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Galeria;