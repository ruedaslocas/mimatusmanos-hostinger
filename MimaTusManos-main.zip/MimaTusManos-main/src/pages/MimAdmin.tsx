import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import Layout from '@/components/Layout';
import { ServicesManager } from '@/components/admin/ServicesManager';
import { TestimonialsManager } from '@/components/admin/TestimonialsManager';
import { CategoriesManager } from '@/components/admin/CategoriesManager';
import { GeneralPhotosManager } from '@/components/admin/GeneralPhotosManager';
import { FeaturedPhotosManager } from '@/components/admin/FeaturedPhotosManager';
import LogoManager from '@/components/admin/LogoManager';
import { Upload, Trash2, Save, LogOut, Menu, X, FileText, Image, Settings, Star, Grid, Camera, Award } from 'lucide-react';

interface SiteContent {
  content_type: string;
  content_value: string;
  description: string;
}

interface PhotoFile {
  name: string;
  url: string;
  created_at: string;
}

const MimAdmin = () => {
  const { user, isAdmin, loading, signOut } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [siteContent, setSiteContent] = useState<SiteContent[]>([]);
  const [photos, setPhotos] = useState<PhotoFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('content');

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      navigate('/auth');
    }
  }, [user, isAdmin, loading, navigate]);

  useEffect(() => {
    if (user && isAdmin) {
      loadSiteContent();
      loadPhotos();
    }
  }, [user, isAdmin]);

  const loadSiteContent = async () => {
    try {
      const { data, error } = await supabase
        .from('site_content')
        .select('*')
        .order('content_type');
      
      if (error) throw error;
      setSiteContent(data || []);
    } catch (error) {
      console.error('Error loading content:', error);
      toast({
        title: "Error",
        description: "No se pudo cargar el contenido del sitio",
        variant: "destructive",
      });
    }
  };

  const loadPhotos = async () => {
    try {
      const { data, error } = await supabase.storage
        .from('admin-photos')
        .list('', { limit: 100, sortBy: { column: 'created_at', order: 'desc' } });
      
      if (error) throw error;
      
      const photosWithUrls = await Promise.all(
        (data || []).map(async (file) => {
          const { data: urlData } = supabase.storage
            .from('admin-photos')
            .getPublicUrl(file.name);
          
          return {
            name: file.name,
            url: urlData.publicUrl,
            created_at: file.created_at || '',
          };
        })
      );
      
      setPhotos(photosWithUrls);
    } catch (error) {
      console.error('Error loading photos:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las fotos",
        variant: "destructive",
      });
    }
  };

  const updateSiteContent = async (contentType: string, newValue: string) => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('site_content')
        .update({ 
          content_value: newValue,
          updated_by: user?.id 
        })
        .eq('content_type', contentType);
      
      if (error) throw error;
      
      setSiteContent(prev => 
        prev.map(item => 
          item.content_type === contentType 
            ? { ...item, content_value: newValue }
            : item
        )
      );
      
      toast({
        title: "Guardado",
        description: "Contenido actualizado correctamente",
      });
    } catch (error) {
      console.error('Error updating content:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar el contenido",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const uploadPhoto = async (file: File) => {
    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      
      const { error } = await supabase.storage
        .from('admin-photos')
        .upload(fileName, file);
      
      if (error) throw error;
      
      await loadPhotos();
      toast({
        title: "Éxito",
        description: "Foto subida correctamente",
      });
    } catch (error) {
      console.error('Error uploading photo:', error);
      toast({
        title: "Error",
        description: "No se pudo subir la foto",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const deletePhoto = async (fileName: string) => {
    try {
      const { error } = await supabase.storage
        .from('admin-photos')
        .remove([fileName]);
      
      if (error) throw error;
      
      await loadPhotos();
      toast({
        title: "Eliminado",
        description: "Foto eliminada correctamente",
      });
    } catch (error) {
      console.error('Error deleting photo:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la foto",
        variant: "destructive",
      });
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  const adminTabs = [
    { id: 'content', label: 'Contenido del Sitio', icon: <FileText className="h-4 w-4" /> },
    { id: 'logo', label: 'Logo', icon: <Image className="h-4 w-4" /> },
    { id: 'categories', label: 'Categorías', icon: <Grid className="h-4 w-4" /> },
    { id: 'services', label: 'Servicios y Precios', icon: <Settings className="h-4 w-4" /> },
    { id: 'testimonials', label: 'Reseñas', icon: <Award className="h-4 w-4" /> },
    { id: 'photos', label: 'Gestión de Fotos', icon: <Camera className="h-4 w-4" /> },
    { id: 'featured', label: 'Fotos Destacadas', icon: <Star className="h-4 w-4" /> },
  ];

  if (loading) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Cargando...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!user || !isAdmin) {
    return null;
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Panel de Administración</h1>
            <p className="text-muted-foreground">Gestiona el contenido de tu sitio web</p>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Mobile Menu Button */}
            <Button
              variant="outline"
              size="sm"
              className="md:hidden flex items-center gap-2 bg-primary/5 border-primary/20 hover:bg-primary/10"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle admin menu"
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              <span className="text-sm font-medium">Menú</span>
            </Button>
            
            <Button onClick={handleLogout} variant="outline" className="hidden md:flex">
              <LogOut className="w-4 h-4 mr-2" />
              Cerrar Sesión
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <div className="md:hidden mb-8 bg-card rounded-lg border border-border p-4 animate-in slide-in-from-top-2 duration-200">
            <div className="flex flex-col space-y-3">
              {adminTabs.map((tab) => (
                <Button
                  key={tab.id}
                  variant={activeTab === tab.id ? "default" : "ghost"}
                  className="justify-start gap-3 w-full"
                  onClick={() => {
                    setActiveTab(tab.id);
                    setIsMenuOpen(false);
                  }}
                >
                  {tab.icon}
                  {tab.label}
                </Button>
              ))}
              <Button
                variant="outline"
                onClick={() => {
                  handleLogout();
                  setIsMenuOpen(false);
                }}
                className="justify-start gap-3 w-full mt-4 border-t pt-4"
              >
                <LogOut className="w-4 h-4" />
                Cerrar Sesión
              </Button>
            </div>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          {/* Desktop TabsList */}
          <TabsList className="hidden md:grid w-full grid-cols-7">
            {adminTabs.map((tab) => (
              <TabsTrigger key={tab.id} value={tab.id} className="flex items-center gap-2">
                {tab.icon}
                <span className="hidden lg:inline">{tab.label}</span>
                <span className="lg:hidden">{tab.label.split(' ')[0]}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="content" className="space-y-6">
            <div className="grid gap-6">
              {siteContent.map((item) => (
                <Card key={item.content_type}>
                  <CardHeader>
                    <CardTitle className="capitalize">{item.content_type}</CardTitle>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {item.content_type === 'description' ? (
                        <Textarea
                          value={item.content_value}
                          onChange={(e) => 
                            setSiteContent(prev => 
                              prev.map(content => 
                                content.content_type === item.content_type
                                  ? { ...content, content_value: e.target.value }
                                  : content
                              )
                            )
                          }
                          rows={4}
                        />
                      ) : (
                        <Input
                          value={item.content_value}
                          onChange={(e) => 
                            setSiteContent(prev => 
                              prev.map(content => 
                                content.content_type === item.content_type
                                  ? { ...content, content_value: e.target.value }
                                  : content
                              )
                            )
                          }
                        />
                      )}
                      <Button
                        onClick={() => updateSiteContent(item.content_type, item.content_value)}
                        disabled={saving}
                        variant="cta"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        {saving ? 'Guardando...' : 'Guardar'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="logo" className="space-y-6">
            <LogoManager />
          </TabsContent>

          <TabsContent value="categories" className="space-y-6">
            <CategoriesManager />
          </TabsContent>

          <TabsContent value="services" className="space-y-6">
            <ServicesManager />
          </TabsContent>

          <TabsContent value="testimonials" className="space-y-6">
            <TestimonialsManager />
          </TabsContent>

          <TabsContent value="photos" className="space-y-6">
            <GeneralPhotosManager />
          </TabsContent>

          <TabsContent value="featured" className="space-y-6">
            <FeaturedPhotosManager />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default MimAdmin;