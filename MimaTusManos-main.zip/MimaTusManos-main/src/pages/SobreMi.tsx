import Layout from "@/components/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, Award, Heart, Users, Clock } from "lucide-react";
import { useSiteConfig } from "@/hooks/useSiteConfig";

const SobreMi = () => {
  const { getConfig } = useSiteConfig();
  const achievements = [
    {
      icon: <Award className="h-8 w-8 text-primary" />,
      title: "Certificación Profesional",
      description: "Titulada en Estética y Belleza con especialización en nail art"
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "+500 Clientas Satisfechas",
      description: "Más de 500 clientas han confiado en nuestros servicios"
    },
    {
      icon: <Clock className="h-8 w-8 text-primary" />,
      title: "5 Años de Experiencia",
      description: "Cinco años perfeccionando técnicas y creando belleza"
    },
    {
      icon: <Heart className="h-8 w-8 text-primary" />,
      title: "Pasión por el Detalle",
      description: "Cada trabajo es único y personalizado para cada clienta"
    }
  ];

  return (
    <Layout>
      {/* Header Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-6">
            Sobre Nosotros
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Conoce la historia y la pasión detrás de MimaTusManos
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Logo */}
            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-background p-12 flex items-center justify-center">
                <img 
                  src="/lovable-uploads/a4b2acb5-5ef8-40d9-a3f0-7d7d84aeddc9.png"
                  alt="Logo de MimaTusManos"
                  className="w-full max-w-md h-auto object-contain"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-background p-6 rounded-2xl shadow-lg border">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary">5+</div>
                  <div className="text-sm text-muted-foreground">Años de experiencia</div>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="space-y-8">
              <div>
                <Badge variant="outline" className="mb-4">
                  Fundadora & Especialista
                </Badge>
                <h2 className="text-3xl font-heading font-bold mb-6">
                  La pasión por la belleza hecha realidad
                </h2>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    Somos <span className="font-semibold text-foreground">MimaTusManos</span>, 
                    un equipo dedicado a la belleza y el cuidado personal. Nuestra pasión por la estética 
                    comenzó hace más de cinco años, cuando decidimos convertir nuestro amor 
                    por el arte en una profesión.
                  </p>
                  <p>
                    Después de formarnos profesionalmente en las mejores academias de estética 
                    y belleza, decidimos crear un espacio donde cada clienta pudiera sentirse 
                    especial y única. En MimaTusManos, cada tratamiento es una obra de arte 
                    personalizada.
                  </p>
                  <p>
                    Nuestra filosofía se basa en tres pilares fundamentales: la calidad en cada 
                    detalle, la higiene como prioridad absoluta, y la creatividad como forma 
                    de expresión. Creemos firmemente que las manos son nuestra carta de presentación, 
                    y por eso nos dedicamos a cuidarlas con el máximo cariño y profesionalidad.
                  </p>
                  <p>
                    Cada día es una oportunidad para crear algo hermoso y hacer que nuestras clientas 
                    se sientan radiantes y seguras de sí mismas. Eso es lo que más nos motiva 
                    en nuestro trabajo.
                  </p>
                </div>
              </div>

              <Button
                variant="cta"
                size="lg"
                className="text-lg px-8 py-4"
                onClick={() => window.open("tel:+34123456789", "_self")}
              >
                <Phone className="h-5 w-5 mr-2" />
                Reservar mi cita
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-20 bg-accent/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">
              Nuestro Compromiso Contigo
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Estos son los valores y logros que definen nuestro trabajo y nuestra dedicación 
              a la excelencia en cada servicio.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <Card key={index} className="text-center border-none shadow-lg">
                <CardContent className="p-8">
                  <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    {achievement.icon}
                  </div>
                  <h3 className="text-lg font-heading font-semibold mb-3">
                    {achievement.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {achievement.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Personal Touch */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Card className="bg-primary text-primary-foreground border-none">
            <CardContent className="p-12 text-center">
              <h2 className="text-2xl md:text-3xl font-heading font-bold mb-6">
                "Nuestro objetivo es que cada clienta salga sintiéndose hermosa, 
                segura y completamente satisfecha con el resultado."
              </h2>
              <p className="text-lg opacity-90 mb-8">
                - Equipo MimaTusManos
              </p>
              <Button
                variant="secondary"
                size="lg"
                className="text-lg px-8 py-4"
                onClick={() => window.open("tel:+34123456789", "_self")}
              >
                <Phone className="h-5 w-5 mr-2" />
                Contactar ahora
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </Layout>
  );
};

export default SobreMi;