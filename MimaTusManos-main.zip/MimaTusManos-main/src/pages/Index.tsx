import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Layout from "@/components/Layout";
import { ImageModal } from "@/components/ImageModal";
import { Phone, Star, Award, Sparkles, Instagram } from "lucide-react";
import { useLatestPhotos } from "@/hooks/useLatestPhotos";
import { useTestimonials } from "@/hooks/useTestimonials";
import { TestimonialForm } from "@/components/TestimonialForm";
import heroImage from "@/assets/hero-nails.jpg";
import instagram1 from "@/assets/instagram-1.jpg";
import instagram2 from "@/assets/instagram-2.jpg";
import instagram3 from "@/assets/instagram-3.jpg";
import instagram4 from "@/assets/instagram-4.jpg";
import instagram5 from "@/assets/instagram-5.jpg";
import instagram6 from "@/assets/instagram-6.jpg";

const Index = () => {
  const { photos, loading: photosLoading } = useLatestPhotos(8);
  const { testimonials } = useTestimonials();

  // Fotos por defecto para mostrar si no hay fotos subidas
  const defaultInstagramPosts = [
    { id: 1, image: instagram1, alt: "Diseño de uñas elegante con detalles en rosa y blanco" },
    { id: 2, image: instagram2, alt: "Nail art con flores y gemas, trabajo profesional" },
    { id: 3, image: instagram3, alt: "Manicura francesa con detalles dorados" },
    { id: 4, image: instagram4, alt: "Arte en uñas con patrones geométricos modernos" },
    { id: 5, image: instagram5, alt: "Diseño colorido con arte rainbow" },
    { id: 6, image: instagram6, alt: "Diseño sofisticado para novias con perlas y encaje" }
  ];

  // Usar fotos subidas si existen, sino usar las por defecto
  const instagramPosts = !photosLoading && photos.length > 0 
    ? photos.slice(0, 8).map((photo, index) => ({
        id: index + 1,
        image: photo.photo_url,
        alt: `Trabajo profesional - ${photo.photo_name}${photo.category_name ? ` - ${photo.category_name}` : ''}`
      }))
    : defaultInstagramPosts;

  // Fallback testimonials in case no database testimonials exist
  const fallbackTestimonials = [
    {
      name: "Patricia M.",
      service: "Manicura semipermanente",
      review_text: "Excelente profesional, muy cuidadosa y detallista. Siempre salgo encantada. El local está impecable y se nota el mimo en cada detalle.",
      rating: 5
    },
    {
      name: "Carmen S.",
      service: "Manicura",
      review_text: "La mejor manicura de la zona sin duda. Trabajo perfecto, muy limpio y gran variedad de colores. Totalmente recomendable.",
      rating: 5
    },
    {
      name: "Ana L.",
      service: "Pedicura",
      review_text: "Increíble el resultado de la pedicura, mis pies quedaron perfectos. Muy profesional y el ambiente súper relajante.",
      rating: 5
    }
  ];

  const displayTestimonials = testimonials.length > 0 ? testimonials : fallbackTestimonials;

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-heading font-bold mb-6">
            El arte de cuidar tus manos
          </h1>
          <p className="text-xl md:text-2xl mb-8 font-light">
            Profesionales en diseño de uñas y estética en tu ciudad
          </p>
          <Button
            variant="cta"
            size="lg"
            className="text-lg px-8 py-4"
            onClick={() => window.open("tel:+34123456789", "_self")}
          >
            <Phone className="h-5 w-5 mr-2" />
            Llamar y pedir cita
          </Button>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">
              Nuestra Filosofía
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              En MimaTusManos creemos que cada detalle cuenta. Nuestro compromiso es brindar 
              un servicio de calidad excepcional, donde la higiene, la creatividad y la 
              profesionalidad se combinan para crear la experiencia perfecta.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-xl font-heading font-semibold mb-2">Calidad</h3>
              <p className="text-muted-foreground">
                Utilizamos únicamente productos premium y técnicas especializadas para 
                garantizar resultados duraderos y hermosos.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-xl font-heading font-semibold mb-2">Higiene</h3>
              <p className="text-muted-foreground">
                Mantenemos los más altos estándares de limpieza y esterilización en 
                todas nuestras herramientas y espacios de trabajo.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-xl font-heading font-semibold mb-2">Creatividad</h3>
              <p className="text-muted-foreground">
                Cada diseño es único y personalizado, adaptado a tu estilo y preferencias 
                para que expreses tu personalidad.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Instagram Gallery */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">
              Nuestros Últimos Trabajos
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Descubre algunas de nuestras creaciones más recientes
            </p>
            <Button 
              variant="outline" 
              className="flex items-center gap-2 mx-auto"
              onClick={() => window.open("https://www.instagram.com/mima.tusmanoss", "_blank")}
            >
              <Instagram className="h-5 w-5" />
              @mima.tusmanoss
            </Button>
          </div>
          
          <div className="grid grid-cols-3 md:grid-cols-4 gap-4">
            {instagramPosts.map((post) => (
              <ImageModal key={post.id} src={post.image} alt={post.alt}>
                <div className="aspect-square rounded-lg overflow-hidden cursor-pointer transform transition-transform hover:scale-105 shadow-lg hover:shadow-xl">
                  <img 
                    src={post.image} 
                    alt={post.alt}
                    className="w-full h-full object-cover"
                  />
                </div>
              </ImageModal>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-accent/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">
              Lo que dicen nuestras clientas
            </h2>
            <p className="text-lg text-muted-foreground">
              La satisfacción de nuestras clientas es nuestra mayor recompensa
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {displayTestimonials.slice(0, 6).map((testimonial, index) => (
              <Card key={index} className="border-none shadow-lg">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-primary text-primary" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.review_text}"</p>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <Badge variant="secondary" className="mt-1">
                      {testimonial.service}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Review Form Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">Comparte tu experiencia</h2>
          <TestimonialForm />
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">
            ¿Lista para mimarte?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Reserva tu cita hoy y descubre la diferencia de un servicio profesional
          </p>
          <Button
            variant="secondary"
            size="lg"
            className="text-lg px-8 py-4"
            onClick={() => window.open("tel:+34123456789", "_self")}
          >
            <Phone className="h-5 w-5 mr-2" />
            Llamar Ahora
          </Button>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
