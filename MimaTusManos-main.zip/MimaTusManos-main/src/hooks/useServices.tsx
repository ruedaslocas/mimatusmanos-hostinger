import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface Service {
  id: string;
  name: string;
  description: string | null;
  duration_minutes: number | null;
  image_url: string | null;
  category: string | null;
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface ServicePrice {
  id: string;
  service_id: string;
  price_type: string;
  price: number;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const useServices = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const loadServices = async () => {
    try {
      const { data, error } = await supabase
        .from('services')
        .select('*')
        .order('display_order', { ascending: true });

      if (error) {
        console.error('Error loading services:', error);
        toast({
          title: "Error",
          description: "No se pudieron cargar los servicios",
          variant: "destructive"
        });
        return;
      }

      setServices(data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const createService = async (serviceData: Omit<Service, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      // Debug: Check authentication
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      console.log('🔐 Current user:', user?.id, 'Auth error:', authError);
      
      // Debug: Check admin role
      if (user) {
        const { data: roleData, error: roleError } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id)
          .single();
        console.log('👤 User role check:', roleData, 'Role error:', roleError);
      }

      console.log('📝 Creating service with data:', serviceData);
      
      const { data, error } = await supabase
        .from('services')
        .insert([serviceData])
        .select()
        .single();

      console.log('✅ Service creation result:', { data, error });

      if (error) {
        console.error('Error creating service:', error);
        toast({
          title: "Error",
          description: "No se pudo crear el servicio",
          variant: "destructive"
        });
        return null;
      }

      toast({
        title: "Servicio creado",
        description: "El servicio se ha creado correctamente"
      });

      await loadServices();
      return data;
    } catch (error) {
      console.error('❌ Error:', error);
      return null;
    }
  };

  const updateService = async (id: string, serviceData: Partial<Service>) => {
    try {
      console.log('🔄 Updating service:', id, 'with data:', serviceData);
      
      const { error } = await supabase
        .from('services')
        .update(serviceData)
        .eq('id', id);

      console.log('✅ Service update result:', { error });

      if (error) {
        console.error('❌ Error updating service:', error);
        toast({
          title: "Error",
          description: "No se pudo actualizar el servicio",
          variant: "destructive"
        });
        return false;
      }

      toast({
        title: "Servicio actualizado",
        description: "El servicio se ha actualizado correctamente"
      });

      await loadServices();
      return true;
    } catch (error) {
      console.error('❌ Error:', error);
      return false;
    }
  };

  const deleteService = async (id: string) => {
    try {
      const { error } = await supabase
        .from('services')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting service:', error);
        toast({
          title: "Error",
          description: "No se pudo eliminar el servicio",
          variant: "destructive"
        });
        return false;
      }

      toast({
        title: "Servicio eliminado",
        description: "El servicio se ha eliminado correctamente"
      });

      await loadServices();
      return true;
    } catch (error) {
      console.error('Error:', error);
      return false;
    }
  };

  useEffect(() => {
    loadServices();
  }, []);

  return {
    services,
    loading,
    createService,
    updateService,
    deleteService,
    refetch: loadServices
  };
};