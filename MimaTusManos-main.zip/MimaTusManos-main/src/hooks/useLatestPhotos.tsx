import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface LatestPhoto {
  id: string;
  photo_name: string;
  photo_url: string;
  category_name?: string;
  created_at: string;
}

export const useLatestPhotos = (limit: number = 6) => {
  const [photos, setPhotos] = useState<LatestPhoto[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchLatestPhotos = async () => {
    try {
      // First try to get featured photos
      const { data: featuredData, error: featuredError } = await supabase
        .from('category_photos')
        .select(`
          id,
          photo_name,
          photo_url,
          created_at,
          categories!inner(
            name,
            is_active
          )
        `)
        .eq('is_featured', true)
        .eq('categories.is_active', true)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (featuredError) throw featuredError;

      let photosToUse = featuredData || [];

      // If we don't have enough featured photos, fill with latest photos
      if (photosToUse.length < limit) {
        const { data: latestData, error: latestError } = await supabase
          .from('category_photos')
          .select(`
            id,
            photo_name,
            photo_url,
            created_at,
            categories!inner(
              name,
              is_active
            )
          `)
          .eq('categories.is_active', true)
          .order('created_at', { ascending: false })
          .limit(limit - photosToUse.length);

        if (latestError) throw latestError;

        // Combine featured and latest photos, avoiding duplicates
        const featuredIds = photosToUse.map(p => p.id);
        const additionalPhotos = (latestData || []).filter(p => !featuredIds.includes(p.id));
        photosToUse = [...photosToUse, ...additionalPhotos].slice(0, limit);
      }

      const formattedPhotos = photosToUse.map(photo => ({
        id: photo.id,
        photo_name: photo.photo_name,
        photo_url: photo.photo_url,
        category_name: photo.categories.name,
        created_at: photo.created_at,
      }));

      setPhotos(formattedPhotos);
    } catch (error) {
      console.error('Error fetching latest photos:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las fotos recientes",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLatestPhotos();
  }, [limit]);

  return {
    photos,
    loading,
    fetchLatestPhotos
  };
};