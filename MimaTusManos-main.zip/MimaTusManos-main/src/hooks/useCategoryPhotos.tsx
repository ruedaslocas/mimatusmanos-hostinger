import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface CategoryPhoto {
  id: string;
  category_id: string;
  photo_name: string;
  photo_url: string;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export const useCategoryPhotos = (categoryId?: string) => {
  const [photos, setPhotos] = useState<CategoryPhoto[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const fetchPhotos = async (catId?: string) => {
    if (!catId && !categoryId) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('category_photos')
        .select('*')
        .eq('category_id', catId || categoryId)
        .order('display_order', { ascending: true });

      if (error) throw error;
      setPhotos(data || []);
    } catch (error) {
      console.error('Error fetching category photos:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las fotos de la categoría",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const uploadPhoto = async (categoryId: string, file: File) => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${categoryId}/${Date.now()}.${fileExt}`;
      
      // Upload file to storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('category-photos')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('category-photos')
        .getPublicUrl(fileName);

      // Save photo record in database
      const { data, error } = await supabase
        .from('category_photos')
        .insert([{
          category_id: categoryId,
          photo_name: file.name,
          photo_url: urlData.publicUrl,
          display_order: photos.length
        }])
        .select()
        .single();

      if (error) throw error;

      await fetchPhotos(categoryId);
      toast({
        title: "Éxito",
        description: "Foto subida correctamente",
      });
      return { data, error: null };
    } catch (error) {
      console.error('Error uploading photo:', error);
      toast({
        title: "Error",
        description: "No se pudo subir la foto",
        variant: "destructive",
      });
      return { data: null, error };
    }
  };

  const uploadMultiplePhotos = async (categoryId: string, files: File[]) => {
    const results = [];
    let successCount = 0;
    let errorCount = 0;

    for (const file of files) {
      try {
        const fileExt = file.name.split('.').pop();
        const fileName = `${categoryId}/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${fileExt}`;
        
        // Upload file to storage
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('category-photos')
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        // Get public URL
        const { data: urlData } = supabase.storage
          .from('category-photos')
          .getPublicUrl(fileName);

        // Save photo record in database
        const { data, error } = await supabase
          .from('category_photos')
          .insert([{
            category_id: categoryId,
            photo_name: file.name,
            photo_url: urlData.publicUrl,
            display_order: photos.length + successCount
          }])
          .select()
          .single();

        if (error) throw error;
        
        results.push({ data, error: null });
        successCount++;
      } catch (error) {
        console.error('Error uploading photo:', error);
        results.push({ data: null, error });
        errorCount++;
      }
    }

    await fetchPhotos(categoryId);
    
    if (successCount > 0) {
      toast({
        title: "Éxito",
        description: `${successCount} foto${successCount > 1 ? 's' : ''} subida${successCount > 1 ? 's' : ''} correctamente${errorCount > 0 ? `. ${errorCount} fallaron.` : ''}`,
      });
    }
    
    if (errorCount > 0 && successCount === 0) {
      toast({
        title: "Error",
        description: "No se pudieron subir las fotos",
        variant: "destructive",
      });
    }

    return results;
  };

  const deletePhoto = async (photoId: string, photoUrl: string) => {
    try {
      // Extract file path from URL
      const urlParts = photoUrl.split('/');
      const fileName = urlParts[urlParts.length - 2] + '/' + urlParts[urlParts.length - 1];

      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('category-photos')
        .remove([fileName]);

      if (storageError) {
        console.error('Storage deletion error:', storageError);
        // Continue with database deletion even if storage fails
      }

      // Delete from database
      const { error: dbError } = await supabase
        .from('category_photos')
        .delete()
        .eq('id', photoId);

      if (dbError) throw dbError;

      await fetchPhotos();
      toast({
        title: "Éxito",
        description: "Foto eliminada correctamente",
      });
      return { error: null };
    } catch (error) {
      console.error('Error deleting photo:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la foto",
        variant: "destructive",
      });
      return { error };
    }
  };

  const updatePhotoOrder = async (photoId: string, newOrder: number) => {
    try {
      const { error } = await supabase
        .from('category_photos')
        .update({ display_order: newOrder })
        .eq('id', photoId);

      if (error) throw error;

      await fetchPhotos();
      return { error: null };
    } catch (error) {
      console.error('Error updating photo order:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar el orden de la foto",
        variant: "destructive",
      });
      return { error };
    }
  };

  useEffect(() => {
    if (categoryId) {
      fetchPhotos();
    }
  }, [categoryId]);

  return {
    photos,
    loading,
    fetchPhotos,
    uploadPhoto,
    uploadMultiplePhotos,
    deletePhoto,
    updatePhotoOrder
  };
};