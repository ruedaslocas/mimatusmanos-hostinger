import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface SiteConfig {
  id: string;
  key: string;
  value: string | null;
  description: string | null;
  created_at: string;
  updated_at: string;
}

export const useSiteConfig = () => {
  const [config, setConfig] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  const fetchConfig = async () => {
    try {
      const { data, error } = await supabase
        .from('site_config')
        .select('*');

      if (error) throw error;

      const configMap = data.reduce((acc, item) => {
        acc[item.key] = item.value || '';
        return acc;
      }, {} as Record<string, string>);

      setConfig(configMap);
    } catch (error) {
      console.error('Error fetching site config:', error);
      toast({
        title: "Error",
        description: "No se pudo cargar la configuración del sitio",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateConfig = async (key: string, value: string) => {
    try {
      const { error } = await supabase
        .from('site_config')
        .upsert({ key, value }, { onConflict: 'key' });

      if (error) throw error;

      setConfig(prev => ({ ...prev, [key]: value }));
      
      toast({
        title: "Configuración actualizada",
        description: "Los cambios se han guardado correctamente",
      });
    } catch (error) {
      console.error('Error updating site config:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar la configuración",
        variant: "destructive",
      });
    }
  };

  const getConfig = (key: string, defaultValue: string = '') => {
    return config[key] || defaultValue;
  };

  useEffect(() => {
    fetchConfig();
    
    // Set up real-time subscription
    const subscription = supabase
      .channel('site_config_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'site_config'
      }, () => {
        fetchConfig();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return {
    config,
    loading,
    updateConfig,
    getConfig,
    refetch: fetchConfig
  };
};