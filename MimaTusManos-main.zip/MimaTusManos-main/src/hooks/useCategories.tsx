import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface Category {
  id: string;
  name: string;
  description?: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const useCategories = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('display_order', { ascending: true });

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las categorías",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const createCategory = async (categoryData: {
    name: string;
    description?: string;
    display_order?: number;
  }) => {
    try {
      // Debug: Check authentication
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      console.log('🔐 Current user:', user?.id, 'Auth error:', authError);
      
      // Debug: Check admin role
      if (user) {
        const { data: roleData, error: roleError } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id)
          .single();
        console.log('👤 User role check:', roleData, 'Role error:', roleError);
      }

      console.log('📝 Creating category with data:', categoryData);
      
      const { data, error } = await supabase
        .from('categories')
        .insert([categoryData])
        .select()
        .single();

      console.log('✅ Category creation result:', { data, error });

      if (error) throw error;

      await fetchCategories();
      toast({
        title: "Éxito",
        description: "Categoría creada correctamente",
      });
      return { data, error: null };
    } catch (error) {
      console.error('❌ Error creating category:', error);
      toast({
        title: "Error",
        description: "No se pudo crear la categoría",
        variant: "destructive",
      });
      return { data: null, error };
    }
  };

  const updateCategory = async (id: string, updates: Partial<Category>) => {
    try {
      console.log('🔄 Updating category:', id, 'with data:', updates);
      
      const { data, error } = await supabase
        .from('categories')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      console.log('✅ Category update result:', { data, error });

      if (error) throw error;

      await fetchCategories();
      toast({
        title: "Éxito",
        description: "Categoría actualizada correctamente",
      });
      return { data, error: null };
    } catch (error) {
      console.error('❌ Error updating category:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar la categoría",
        variant: "destructive",
      });
      return { data: null, error };
    }
  };

  const deleteCategory = async (id: string) => {
    try {
      const { error } = await supabase
        .from('categories')
        .delete()
        .eq('id', id);

      if (error) throw error;

      await fetchCategories();
      toast({
        title: "Éxito",
        description: "Categoría eliminada correctamente",
      });
      return { error: null };
    } catch (error) {
      console.error('Error deleting category:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la categoría",
        variant: "destructive",
      });
      return { error };
    }
  };

  const getActiveCategories = () => {
    return categories.filter(category => category.is_active);
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  return {
    categories,
    loading,
    fetchCategories,
    createCategory,
    updateCategory,
    deleteCategory,
    getActiveCategories
  };
};