import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface Testimonial {
  id: string;
  name: string;
  service: string;
  review_text: string;
  rating: number;
  is_approved: boolean;
  created_at: string;
  updated_at: string;
}

export interface CreateTestimonialData {
  name: string;
  service: string;
  review_text: string;
  rating: number;
}

export const useTestimonials = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: testimonials = [], isLoading } = useQuery({
    queryKey: ["testimonials"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("testimonials")
        .select("*")
        .eq("is_approved", true)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as Testimonial[];
    },
  });

  const createTestimonial = useMutation({
    mutationFn: async (testimonialData: CreateTestimonialData) => {
      const { data, error } = await supabase
        .from("testimonials")
        .insert([testimonialData])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast({
        title: "¡Reseña enviada!",
        description: "Tu reseña está pendiente de aprobación. ¡Gracias por tu opinión!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "No se pudo enviar la reseña. Inténtalo de nuevo.",
        variant: "destructive",
      });
    },
  });

  return {
    testimonials,
    isLoading,
    createTestimonial,
  };
};

export const useAdminTestimonials = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: allTestimonials = [], isLoading } = useQuery({
    queryKey: ["admin-testimonials"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("testimonials")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as Testimonial[];
    },
  });

  const approveTestimonial = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("testimonials")
        .update({ is_approved: true })
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-testimonials"] });
      queryClient.invalidateQueries({ queryKey: ["testimonials"] });
      toast({
        title: "Reseña aprobada",
        description: "La reseña ahora es visible públicamente.",
      });
    },
  });

  const deleteTestimonial = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("testimonials")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-testimonials"] });
      queryClient.invalidateQueries({ queryKey: ["testimonials"] });
      toast({
        title: "Reseña eliminada",
        description: "La reseña ha sido eliminada correctamente.",
      });
    },
  });

  return {
    allTestimonials,
    isLoading,
    approveTestimonial,
    deleteTestimonial,
  };
};