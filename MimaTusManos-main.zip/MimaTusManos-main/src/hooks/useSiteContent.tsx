import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface SiteContent {
  content_type: string;
  content_value: string;
  description?: string;
}

export const useSiteContent = () => {
  const [content, setContent] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  const loadContent = async () => {
    try {
      const { data, error } = await supabase
        .from('site_content')
        .select('content_type, content_value');

      if (error) {
        if (process.env.NODE_ENV === 'development') {
          console.error('Error loading site content:', error);
        }
        return;
      }

      const contentMap = data.reduce((acc, item) => {
        acc[item.content_type] = item.content_value;
        return acc;
      }, {} as Record<string, string>);

      setContent(contentMap);
    } catch (error) {
      if (process.env.NODE_ENV === 'development') {
        console.error('Error:', error);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContent();

    // Suscribirse a cambios en tiempo real
    const subscription = supabase
      .channel('site_content_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'site_content'
        },
        () => {
          loadContent();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  // Función helper para obtener contenido con fallback
  const getContent = (key: string, fallback: string = '') => {
    return content[key] || fallback;
  };

  return { content, loading, getContent, refetch: loadContent };
};