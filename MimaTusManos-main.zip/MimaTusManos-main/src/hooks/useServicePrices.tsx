import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { ServicePrice } from './useServices';

export const useServicePrices = (serviceId?: string) => {
  const [prices, setPrices] = useState<ServicePrice[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const loadPrices = async () => {
    try {
      let query = supabase
        .from('service_prices')
        .select('*')
        .order('price_type', { ascending: true });

      if (serviceId) {
        query = query.eq('service_id', serviceId);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error loading service prices:', error);
        toast({
          title: "Error",
          description: "No se pudieron cargar los precios",
          variant: "destructive"
        });
        return;
      }

      setPrices(data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const createPrice = async (priceData: Omit<ServicePrice, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      // Debug: Check authentication
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      console.log('🔐 Current user for price creation:', user?.id, 'Auth error:', authError);
      
      console.log('💰 Creating price with data:', priceData);
      
      const { data, error } = await supabase
        .from('service_prices')
        .insert([priceData])
        .select()
        .single();

      console.log('✅ Price creation result:', { data, error });

      if (error) {
        console.error('❌ Error creating price:', error);
        toast({
          title: "Error",
          description: "No se pudo crear el precio",
          variant: "destructive"
        });
        return null;
      }

      toast({
        title: "Precio creado",
        description: "El precio se ha creado correctamente"
      });

      await loadPrices();
      return data;
    } catch (error) {
      console.error('❌ Error:', error);
      return null;
    }
  };

  const updatePrice = async (id: string, priceData: Partial<ServicePrice>) => {
    try {
      console.log('🔄 Updating price:', id, 'with data:', priceData);
      
      const { error } = await supabase
        .from('service_prices')
        .update(priceData)
        .eq('id', id);

      console.log('✅ Price update result:', { error });

      if (error) {
        console.error('❌ Error updating price:', error);
        toast({
          title: "Error",
          description: "No se pudo actualizar el precio",
          variant: "destructive"
        });
        return false;
      }

      toast({
        title: "Precio actualizado",
        description: "El precio se ha actualizado correctamente"
      });

      await loadPrices();
      return true;
    } catch (error) {
      console.error('❌ Error:', error);
      return false;
    }
  };

  const deletePrice = async (id: string) => {
    try {
      const { error } = await supabase
        .from('service_prices')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting price:', error);
        toast({
          title: "Error",
          description: "No se pudo eliminar el precio",
          variant: "destructive"
        });
        return false;
      }

      toast({
        title: "Precio eliminado",
        description: "El precio se ha eliminado correctamente"
      });

      await loadPrices();
      return true;
    } catch (error) {
      console.error('Error:', error);
      return false;
    }
  };

  useEffect(() => {
    loadPrices();
  }, [serviceId]);

  return {
    prices,
    loading,
    createPrice,
    updatePrice,
    deletePrice,
    refetch: loadPrices
  };
};