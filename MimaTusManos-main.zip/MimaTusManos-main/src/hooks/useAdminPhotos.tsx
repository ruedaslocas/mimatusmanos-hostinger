import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface PhotoFile {
  name: string;
  url: string;
  created_at?: string;
}

export const useAdminPhotos = () => {
  const [photos, setPhotos] = useState<PhotoFile[]>([]);
  const [loading, setLoading] = useState(true);

  const loadPhotos = async () => {
    try {
      const { data, error } = await supabase.storage
        .from('admin-photos')
        .list('', {
          limit: 100,
          offset: 0,
          sortBy: { column: 'created_at', order: 'desc' }
        });

      if (error) {
        console.error('Error loading photos:', error);
        return;
      }

      const photosWithUrls = await Promise.all(
        data.map(async (file) => {
          const { data: urlData } = supabase.storage
            .from('admin-photos')
            .getPublicUrl(file.name);
          
          return {
            name: file.name,
            url: urlData.publicUrl,
            created_at: file.created_at
          };
        })
      );

      setPhotos(photosWithUrls);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPhotos();
  }, []);

  return { photos, loading, refetch: loadPhotos };
};