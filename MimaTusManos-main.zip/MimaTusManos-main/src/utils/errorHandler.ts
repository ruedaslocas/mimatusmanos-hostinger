import { toast } from '@/hooks/use-toast';

interface ErrorHandlerOptions {
  showToast?: boolean;
  toastTitle?: string;
  toastDescription?: string;
  logToConsole?: boolean;
}

export const handleError = (
  error: any,
  context: string,
  options: ErrorHandlerOptions = {}
) => {
  const {
    showToast = false,
    toastTitle = 'Error',
    toastDescription,
    logToConsole = true
  } = options;

  // Log to console in development only
  if (logToConsole && process.env.NODE_ENV === 'development') {
    console.error(`[${context}]:`, error);
  }

  // Show toast notification if requested
  if (showToast) {
    toast({
      title: toastTitle,
      description: toastDescription || error.message || 'Ha ocurrido un error',
      variant: 'destructive',
    });
  }

  return error;
};

export const handleSuccess = (
  message: string,
  title: string = '¡Éxito!'
) => {
  toast({
    title,
    description: message,
  });
};