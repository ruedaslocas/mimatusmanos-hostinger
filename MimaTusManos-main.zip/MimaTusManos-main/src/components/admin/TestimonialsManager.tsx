import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Check, Trash2 } from "lucide-react";
import { useAdminTestimonials } from "@/hooks/useTestimonials";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

export const TestimonialsManager = () => {
  const { allTestimonials, isLoading, approveTestimonial, deleteTestimonial } = useAdminTestimonials();

  if (isLoading) {
    return <div>Cargando reseñas...</div>;
  }

  const pendingTestimonials = allTestimonials.filter(t => !t.is_approved);
  const approvedTestimonials = allTestimonials.filter(t => t.is_approved);

  return (
    <div className="space-y-6">
      {pendingTestimonials.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4">Reseñas pendientes de aprobación ({pendingTestimonials.length})</h3>
          <div className="grid gap-4">
            {pendingTestimonials.map((testimonial) => (
              <Card key={testimonial.id} className="border-yellow-200">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-sm">{testimonial.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">{testimonial.service}</p>
                    </div>
                    <div className="flex items-center space-x-1">
                      {Array.from({ length: testimonial.rating }).map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                  <Badge variant="secondary">Pendiente</Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-4">{testimonial.review_text}</p>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      onClick={() => approveTestimonial.mutate(testimonial.id)}
                      disabled={approveTestimonial.isPending}
                    >
                      <Check className="h-4 w-4 mr-1" />
                      Aprobar
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm">
                          <Trash2 className="h-4 w-4 mr-1" />
                          Eliminar
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Eliminar reseña?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Esta acción no se puede deshacer. La reseña será eliminada permanentemente.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => deleteTestimonial.mutate(testimonial.id)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Eliminar
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <div>
        <h3 className="text-lg font-semibold mb-4">Reseñas aprobadas ({approvedTestimonials.length})</h3>
        <div className="grid gap-4">
          {approvedTestimonials.map((testimonial) => (
            <Card key={testimonial.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-sm">{testimonial.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">{testimonial.service}</p>
                  </div>
                  <div className="flex items-center space-x-1">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </div>
                <Badge variant="default">Aprobada</Badge>
              </CardHeader>
              <CardContent>
                <p className="text-sm mb-4">{testimonial.review_text}</p>
                <div className="flex justify-end">
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm">
                        <Trash2 className="h-4 w-4 mr-1" />
                        Eliminar
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>¿Eliminar reseña?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Esta acción no se puede deshacer. La reseña será eliminada permanentemente.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => deleteTestimonial.mutate(testimonial.id)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Eliminar
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {allTestimonials.length === 0 && (
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground">No hay reseñas todavía.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};