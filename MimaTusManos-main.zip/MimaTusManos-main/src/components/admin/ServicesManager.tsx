import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { useServices } from '@/hooks/useServices';
import { useServicePrices } from '@/hooks/useServicePrices';
import { ServiceForm } from './ServiceForm';
import { PriceForm } from './PriceForm';
import { Edit, Trash2, Clock, Euro, Eye, EyeOff } from 'lucide-react';

export const ServicesManager = () => {
  const { services, loading: servicesLoading, createService, updateService, deleteService } = useServices();
  const { prices, loading: pricesLoading, createPrice, updatePrice, deletePrice, refetch: refetchPrices } = useServicePrices();
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(null);

  const getServicePrices = (serviceId: string) => {
    return prices.filter(price => price.service_id === serviceId);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'EUR'
    }).format(price);
  };

  const getPriceTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      base: 'Base',
      premium: 'Premium',
      deluxe: 'Deluxe',
      promocion: 'Promoción'
    };
    return labels[type] || type;
  };

  const getCategoryLabel = (category: string | null) => {
    const labels: Record<string, string> = {
      manicura: 'Manicura',
      pedicura: 'Pedicura',
      cejas: 'Cejas',
      depilacion: 'Depilación',
      tratamientos: 'Tratamientos'
    };
    return category ? labels[category] || category : 'Sin categoría';
  };

  if (servicesLoading) {
    return <div className="p-6">Cargando servicios...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestión de Servicios y Precios</h2>
        <ServiceForm onSubmit={createService} />
      </div>

      <div className="grid gap-6">
        {services.map((service) => {
          const servicePrices = getServicePrices(service.id);
          const isExpanded = selectedServiceId === service.id;

          return (
            <Card key={service.id} className="border">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <CardTitle className="text-lg">{service.name}</CardTitle>
                      <Badge variant={service.is_active ? "default" : "secondary"}>
                        {service.is_active ? (
                          <><Eye className="h-3 w-3 mr-1" /> Activo</>
                        ) : (
                          <><EyeOff className="h-3 w-3 mr-1" /> Inactivo</>
                        )}
                      </Badge>
                      <Badge variant="outline">
                        {getCategoryLabel(service.category)}
                      </Badge>
                    </div>
                    {service.description && (
                      <p className="text-sm text-muted-foreground mb-2">{service.description}</p>
                    )}
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      {service.duration_minutes && (
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {service.duration_minutes} min
                        </div>
                      )}
                      <div className="flex items-center gap-1">
                        <Euro className="h-4 w-4" />
                        {servicePrices.length} precio(s)
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedServiceId(isExpanded ? null : service.id)}
                    >
                      {isExpanded ? 'Ocultar' : 'Ver'} Precios
                    </Button>
                    <ServiceForm
                      service={service}
                      onSubmit={(data) => updateService(service.id, data)}
                      trigger={
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      }
                    />
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Eliminar servicio?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Esta acción no se puede deshacer. Se eliminará el servicio "{service.name}" y todos sus precios asociados.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteService(service.id)}>
                            Eliminar
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardHeader>

              {isExpanded && (
                <CardContent>
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="font-semibold">Precios del Servicio</h4>
                     <PriceForm
                       serviceId={service.id}
                       onSubmit={async (data) => {
                         const result = await createPrice(data);
                         if (result) {
                           await refetchPrices();
                         }
                         return result;
                       }}
                     />
                  </div>

                  {servicePrices.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Tipo</TableHead>
                          <TableHead>Precio</TableHead>
                          <TableHead>Descripción</TableHead>
                          <TableHead>Estado</TableHead>
                          <TableHead>Acciones</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {servicePrices.map((price) => (
                          <TableRow key={price.id}>
                            <TableCell>
                              <Badge variant="outline">
                                {getPriceTypeLabel(price.price_type)}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-semibold">
                              {formatPrice(price.price)}
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {price.description || '-'}
                            </TableCell>
                            <TableCell>
                              <Badge variant={price.is_active ? "default" : "secondary"}>
                                {price.is_active ? 'Activo' : 'Inactivo'}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                 <PriceForm
                                   price={price}
                                   serviceId={service.id}
                                   onSubmit={async (data) => {
                                     const result = await updatePrice(price.id, data);
                                     if (result) {
                                       await refetchPrices();
                                     }
                                     return result;
                                   }}
                                   trigger={
                                     <Button variant="outline" size="sm">
                                       <Edit className="h-3 w-3" />
                                     </Button>
                                   }
                                 />
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button variant="outline" size="sm">
                                      <Trash2 className="h-3 w-3" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>¿Eliminar precio?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        Esta acción no se puede deshacer. Se eliminará el precio "{getPriceTypeLabel(price.price_type)}" de {formatPrice(price.price)}.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                       <AlertDialogAction onClick={async () => {
                                         const result = await deletePrice(price.id);
                                         if (result) {
                                           await refetchPrices();
                                         }
                                       }}>
                                         Eliminar
                                       </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>No hay precios configurados para este servicio</p>
                      <p className="text-sm">Usa el botón "Nuevo Precio" para añadir precios</p>
                    </div>
                  )}
                </CardContent>
              )}
            </Card>
          );
        })}
      </div>

      {services.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-muted-foreground mb-4">No hay servicios configurados</p>
            <ServiceForm onSubmit={createService} />
          </CardContent>
        </Card>
      )}
    </div>
  );
};