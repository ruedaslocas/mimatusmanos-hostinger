import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Trash2, Upload, Image, Edit3 } from "lucide-react";
import { useCategories } from "@/hooks/useCategories";
import { useCategoryPhotos } from "@/hooks/useCategoryPhotos";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";

export const GeneralPhotosManager = () => {
  const { categories } = useCategories();
  const { photos: categoryPhotos, fetchPhotos } = useCategoryPhotos();
  const [uploading, setUploading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [editingPhoto, setEditingPhoto] = useState<any>(null);
  const [newCategory, setNewCategory] = useState<string>("");
  const { toast } = useToast();

  // Get all photos from all categories
  const [allPhotos, setAllPhotos] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchAllPhotos = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('category_photos')
        .select(`
          *,
          categories(name, id)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setAllPhotos(data || []);
    } catch (error) {
      console.error('Error fetching all photos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (files: FileList) => {
    const validFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
    
    if (validFiles.length === 0) {
      toast({
        title: "Error",
        description: "Por favor selecciona archivos de imagen válidos",
        variant: "destructive",
      });
      return;
    }

    if (!selectedCategory) {
      toast({
        title: "Error",
        description: "Por favor selecciona una categoría",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    let successCount = 0;
    let errorCount = 0;

    try {
      for (const file of validFiles) {
        try {
          const fileExt = file.name.split('.').pop();
          const fileName = `${selectedCategory}/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${fileExt}`;
          
          // Upload file to storage
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from('category-photos')
            .upload(fileName, file);

          if (uploadError) throw uploadError;

          // Get public URL
          const { data: urlData } = supabase.storage
            .from('category-photos')
            .getPublicUrl(fileName);

          // Save photo record in database
          const { error } = await supabase
            .from('category_photos')
            .insert([{
              category_id: selectedCategory,
              photo_name: file.name,
              photo_url: urlData.publicUrl,
              display_order: 0
            }]);

          if (error) throw error;
          successCount++;
        } catch (error) {
          console.error('Error uploading photo:', error);
          errorCount++;
        }
      }

      await fetchAllPhotos();
      setSelectedCategory("");
      
      if (successCount > 0) {
        toast({
          title: "Éxito",
          description: `${successCount} foto${successCount > 1 ? 's' : ''} subida${successCount > 1 ? 's' : ''} correctamente${errorCount > 0 ? `. ${errorCount} fallaron.` : ''}`,
        });
      }
      
      if (errorCount > 0 && successCount === 0) {
        toast({
          title: "Error",
          description: "No se pudieron subir las fotos",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error uploading photos:', error);
      toast({
        title: "Error",
        description: "Error general al subir las fotos",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleDeletePhoto = async (photoId: string, photoUrl: string) => {
    try {
      // Extract file path from URL
      const urlParts = photoUrl.split('/');
      const fileName = urlParts[urlParts.length - 2] + '/' + urlParts[urlParts.length - 1];

      // Delete from storage
      await supabase.storage
        .from('category-photos')
        .remove([fileName]);

      // Delete from database
      const { error } = await supabase
        .from('category_photos')
        .delete()
        .eq('id', photoId);

      if (error) throw error;

      await fetchAllPhotos();
      toast({
        title: "Éxito",
        description: "Foto eliminada correctamente",
      });
    } catch (error) {
      console.error('Error deleting photo:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la foto",
        variant: "destructive",
      });
    }
  };

  const handleUpdatePhotoCategory = async () => {
    if (!editingPhoto || !newCategory) return;

    try {
      const { error } = await supabase
        .from('category_photos')
        .update({ category_id: newCategory })
        .eq('id', editingPhoto.id);

      if (error) throw error;

      await fetchAllPhotos();
      setEditingPhoto(null);
      setNewCategory("");
      toast({
        title: "Éxito",
        description: "Categoría actualizada correctamente",
      });
    } catch (error) {
      console.error('Error updating photo category:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar la categoría",
        variant: "destructive",
      });
    }
  };

  // Load photos on component mount
  useEffect(() => {
    fetchAllPhotos();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestión General de Fotos</h2>
        <Button onClick={fetchAllPhotos} variant="outline">
          Actualizar
        </Button>
      </div>

      {/* Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle>Subir Nueva Foto</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Categoría *</Label>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona una categoría" />
              </SelectTrigger>
              <SelectContent>
                {categories.filter(cat => cat.is_active).map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Label htmlFor="general-photo-upload" className="cursor-pointer">
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center hover:border-primary/50 transition-colors">
              <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-medium">Arrastra fotos aquí o haz clic para seleccionar</p>
              <p className="text-sm text-muted-foreground">Selecciona una o varias fotos (PNG, JPG, JPEG)</p>
            </div>
            <Input
              id="general-photo-upload"
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => {
                const files = e.target.files;
                if (files && files.length > 0) {
                  handleFileUpload(files);
                }
              }}
              disabled={uploading}
            />
          </Label>
          {uploading && (
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Subiendo foto...</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Photos Grid */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Image className="h-5 w-5" />
            Todas las Fotos
            <Badge variant="secondary">{allPhotos.length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="aspect-square bg-muted animate-pulse rounded-lg" />
              ))}
            </div>
          ) : allPhotos.length === 0 ? (
            <div className="text-center py-8">
              <Image className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No hay fotos subidas</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {allPhotos.map((photo) => (
                <div key={photo.id} className="relative group">
                  <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                    <img
                      src={photo.photo_url}
                      alt={photo.photo_name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  {/* Photo Controls */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => {
                            setEditingPhoto(photo);
                            setNewCategory(photo.category_id);
                          }}
                        >
                          <Edit3 className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Cambiar Categoría</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label>Nueva Categoría</Label>
                            <Select value={newCategory} onValueChange={setNewCategory}>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecciona una categoría" />
                              </SelectTrigger>
                              <SelectContent>
                                {categories.filter(cat => cat.is_active).map((category) => (
                                  <SelectItem key={category.id} value={category.id}>
                                    {category.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex gap-2">
                            <Button onClick={handleUpdatePhotoCategory}>
                              Actualizar
                            </Button>
                            <Button variant="outline" onClick={() => setEditingPhoto(null)}>
                              Cancelar
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Eliminar foto?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Esta acción eliminará la foto permanentemente. No se puede deshacer.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDeletePhoto(photo.id, photo.photo_url)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Eliminar
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                  
                  {/* Photo Info */}
                  <div className="mt-2">
                    <p className="text-xs text-muted-foreground truncate">{photo.photo_name}</p>
                    <Badge variant="outline" className="text-xs">
                      {photo.categories?.name || 'Sin categoría'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};