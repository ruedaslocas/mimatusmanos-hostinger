import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trash2, Edit, Plus, Image } from "lucide-react";
import { useCategories, Category } from "@/hooks/useCategories";
import { CategoryForm } from "./CategoryForm";
import { CategoryPhotosManager } from "./CategoryPhotosManager";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export const CategoriesManager = () => {
  const { categories, loading, createCategory, updateCategory, deleteCategory } = useCategories();
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleCreateCategory = async (data: {
    name: string;
    description?: string;
    display_order: number;
    is_active: boolean;
  }) => {
    setIsSubmitting(true);
    const result = await createCategory(data);
    if (result.error === null) {
      setShowForm(false);
    }
    setIsSubmitting(false);
  };

  const handleUpdateCategory = async (data: {
    name: string;
    description?: string;
    display_order: number;
    is_active: boolean;
  }) => {
    if (!editingCategory) return;
    
    setIsSubmitting(true);
    const result = await updateCategory(editingCategory.id, data);
    if (result.error === null) {
      setEditingCategory(null);
    }
    setIsSubmitting(false);
  };

  const handleDeleteCategory = async (categoryId: string) => {
    await deleteCategory(categoryId);
  };

  if (loading) {
    return <div>Cargando categorías...</div>;
  }

  if (showForm) {
    return (
      <CategoryForm
        onSubmit={handleCreateCategory}
        onCancel={() => setShowForm(false)}
        isLoading={isSubmitting}
      />
    );
  }

  if (editingCategory) {
    return (
      <CategoryForm
        category={editingCategory}
        onSubmit={handleUpdateCategory}
        onCancel={() => setEditingCategory(null)}
        isLoading={isSubmitting}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestión de Categorías</h2>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Nueva Categoría
        </Button>
      </div>

      <div className="grid gap-6">
        {categories.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-muted-foreground">No hay categorías creadas</p>
              <Button onClick={() => setShowForm(true)} className="mt-4">
                <Plus className="h-4 w-4 mr-2" />
                Crear primera categoría
              </Button>
            </CardContent>
          </Card>
        ) : (
          categories.map((category) => (
            <Card key={category.id}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {category.name}
                      <Badge variant={category.is_active ? "default" : "secondary"}>
                        {category.is_active ? "Activa" : "Inactiva"}
                      </Badge>
                    </CardTitle>
                    {category.description && (
                      <p className="text-sm text-muted-foreground mt-1">
                        {category.description}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingCategory(category)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Eliminar categoría?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Esta acción eliminará la categoría "{category.name}" permanentemente.
                            Los servicios asociados a esta categoría quedarán sin categoría asignada.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDeleteCategory(category.id)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Eliminar
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="info" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="info">Información</TabsTrigger>
                    <TabsTrigger value="photos" className="flex items-center gap-2">
                      <Image className="h-4 w-4" />
                      Fotos
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="info" className="mt-4">
                    <div className="text-sm text-muted-foreground">
                      Orden: {category.display_order}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="photos" className="mt-4">
                    <CategoryPhotosManager 
                      categoryId={category.id} 
                      categoryName={category.name}
                    />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};