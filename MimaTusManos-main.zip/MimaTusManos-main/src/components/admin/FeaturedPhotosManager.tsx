import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, StarOff, Image } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface FeaturedPhoto {
  id: string;
  photo_name: string;
  photo_url: string;
  is_featured: boolean;
  categories?: {
    name: string;
  };
}

export const FeaturedPhotosManager = () => {
  const [allPhotos, setAllPhotos] = useState<FeaturedPhoto[]>([]);
  const [featuredPhotos, setFeaturedPhotos] = useState<FeaturedPhoto[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const fetchPhotos = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('category_photos')
        .select(`
          *,
          categories(name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const photos = data || [];
      setAllPhotos(photos);
      setFeaturedPhotos(photos.filter(photo => photo.is_featured));
    } catch (error) {
      console.error('Error fetching photos:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las fotos",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleFeatured = async (photoId: string, currentStatus: boolean) => {
    try {
      // Check if trying to feature more than 6 photos
      if (!currentStatus && featuredPhotos.length >= 8) {
        toast({
          title: "Límite alcanzado",
          description: "Solo puedes destacar un máximo de 8 fotos",
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from('category_photos')
        .update({ is_featured: !currentStatus })
        .eq('id', photoId);

      if (error) throw error;

      await fetchPhotos();
      toast({
        title: "Éxito",
        description: currentStatus ? "Foto removida de destacadas" : "Foto añadida a destacadas",
      });
    } catch (error) {
      console.error('Error updating featured status:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar el estado",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchPhotos();
  }, []);

  if (loading) {
    return <div>Cargando fotos...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Fotos Destacadas para Página Principal</h2>
        <Button onClick={fetchPhotos} variant="outline">
          Actualizar
        </Button>
      </div>

      {/* Featured Photos Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-yellow-500" />
            Fotos Destacadas Actuales
            <Badge variant="secondary">{featuredPhotos.length}/8</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {featuredPhotos.length === 0 ? (
            <div className="text-center py-8">
              <Star className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No hay fotos destacadas</p>
              <p className="text-sm text-muted-foreground">Selecciona hasta 8 fotos para mostrar en la página principal</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {featuredPhotos.map((photo) => (
                <div key={photo.id} className="relative group">
                  <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                    <img
                      src={photo.photo_url}
                      alt={photo.photo_name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute top-2 left-2">
                    <Badge className="bg-yellow-500 text-white">
                      <Star className="h-3 w-3 mr-1" />
                      Destacada
                    </Badge>
                  </div>
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => toggleFeatured(photo.id, true)}
                    >
                      <StarOff className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="mt-2">
                    <p className="text-xs text-muted-foreground truncate">{photo.photo_name}</p>
                    <Badge variant="outline" className="text-xs">
                      {photo.categories?.name}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* All Photos Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Image className="h-5 w-5" />
            Todas las Fotos Disponibles
            <Badge variant="secondary">{allPhotos.filter(p => !p.is_featured).length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {allPhotos.filter(p => !p.is_featured).length === 0 ? (
            <div className="text-center py-8">
              <Image className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">Todas las fotos están destacadas</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {allPhotos.filter(p => !p.is_featured).map((photo) => (
                <div key={photo.id} className="relative group">
                  <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                    <img
                      src={photo.photo_url}
                      alt={photo.photo_name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => toggleFeatured(photo.id, false)}
                      disabled={featuredPhotos.length >= 8}
                    >
                      <Star className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="mt-2">
                    <p className="text-xs text-muted-foreground truncate">{photo.photo_name}</p>
                    <Badge variant="outline" className="text-xs">
                      {photo.categories?.name}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};