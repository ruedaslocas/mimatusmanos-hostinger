import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Trash2, Upload, Image, MoveUp, MoveDown } from "lucide-react";
import { useCategoryPhotos, CategoryPhoto } from "@/hooks/useCategoryPhotos";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface CategoryPhotosManagerProps {
  categoryId: string;
  categoryName: string;
}

export const CategoryPhotosManager = ({ categoryId, categoryName }: CategoryPhotosManagerProps) => {
  const { photos, loading, uploadPhoto, uploadMultiplePhotos, deletePhoto, updatePhotoOrder } = useCategoryPhotos(categoryId);
  const [uploading, setUploading] = useState(false);

  const handleFileUpload = async (files: FileList) => {
    const validFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
    
    if (validFiles.length === 0) {
      return;
    }

    setUploading(true);
    if (validFiles.length === 1) {
      await uploadPhoto(categoryId, validFiles[0]);
    } else {
      await uploadMultiplePhotos(categoryId, validFiles);
    }
    setUploading(false);
  };

  const handleDeletePhoto = async (photo: CategoryPhoto) => {
    await deletePhoto(photo.id, photo.photo_url);
  };

  const handleMovePhoto = async (photoId: string, direction: 'up' | 'down') => {
    const currentPhoto = photos.find(p => p.id === photoId);
    if (!currentPhoto) return;

    const currentIndex = photos.findIndex(p => p.id === photoId);
    const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    
    if (newIndex < 0 || newIndex >= photos.length) return;

    const targetPhoto = photos[newIndex];
    
    // Swap display orders
    await updatePhotoOrder(currentPhoto.id, targetPhoto.display_order);
    await updatePhotoOrder(targetPhoto.id, currentPhoto.display_order);
  };

  if (loading) {
    return <div>Cargando fotos...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Image className="h-5 w-5" />
          Fotos de {categoryName}
          <Badge variant="secondary">{photos.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Upload Section */}
        <div className="space-y-4">
          <Label htmlFor={`photo-upload-${categoryId}`} className="cursor-pointer">
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center hover:border-primary/50 transition-colors">
              <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
              <p className="font-medium">Subir fotos</p>
              <p className="text-sm text-muted-foreground">Selecciona una o varias fotos (PNG, JPG, JPEG)</p>
            </div>
            <Input
              id={`photo-upload-${categoryId}`}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => {
                const files = e.target.files;
                if (files && files.length > 0) {
                  handleFileUpload(files);
                }
              }}
              disabled={uploading}
            />
          </Label>
          {uploading && (
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Subiendo foto...</p>
            </div>
          )}
        </div>

        {/* Photos Grid */}
        {photos.length === 0 ? (
          <div className="text-center py-8">
            <Image className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">No hay fotos en esta categoría</p>
            <p className="text-sm text-muted-foreground">Sube la primera foto para comenzar</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {photos.map((photo, index) => (
              <div key={photo.id} className="relative group">
                <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                  <img
                    src={photo.photo_url}
                    alt={photo.photo_name}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                {/* Photo Controls */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => handleMovePhoto(photo.id, 'up')}
                    disabled={index === 0}
                  >
                    <MoveUp className="h-4 w-4" />
                  </Button>
                  
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => handleMovePhoto(photo.id, 'down')}
                    disabled={index === photos.length - 1}
                  >
                    <MoveDown className="h-4 w-4" />
                  </Button>
                  
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>¿Eliminar foto?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Esta acción eliminará la foto permanentemente. No se puede deshacer.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDeletePhoto(photo)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Eliminar
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
                
                {/* Photo Info */}
                <div className="mt-2">
                  <p className="text-xs text-muted-foreground truncate">{photo.photo_name}</p>
                  <p className="text-xs text-muted-foreground">Orden: {photo.display_order + 1}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};