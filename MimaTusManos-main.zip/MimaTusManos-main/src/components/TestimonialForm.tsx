import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Star } from "lucide-react";
import { useTestimonials } from "@/hooks/useTestimonials";
import { useToast } from "@/hooks/use-toast";

// Input sanitization function to prevent XSS and clean user input
const sanitizeInput = (input: string): string => {
  return input
    .trim()
    .replace(/[<>\"'&]/g, (match) => {
      const map: { [key: string]: string } = {
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;',
        '&': '&amp;'
      };
      return map[match];
    })
    .slice(0, 500); // Limit input length
};

export const TestimonialForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    service: "",
    review_text: "",
    rating: 5,
  });

  const { createTestimonial } = useTestimonials();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!formData.name.trim() || !formData.service || !formData.review_text.trim()) {
      toast({
        title: "Error",
        description: "Por favor, completa todos los campos obligatorios.",
        variant: "destructive",
      });
      return;
    }

    // Additional validation
    if (formData.name.length < 2) {
      toast({
        title: "Error",
        description: "El nombre debe tener al menos 2 caracteres.",
        variant: "destructive",
      });
      return;
    }

    if (formData.review_text.length < 10) {
      toast({
        title: "Error", 
        description: "La reseña debe tener al menos 10 caracteres.",
        variant: "destructive",
      });
      return;
    }

    // Sanitize input data
    const sanitizedData = {
      ...formData,
      name: sanitizeInput(formData.name),
      review_text: sanitizeInput(formData.review_text),
    };
    
    createTestimonial.mutate(sanitizedData, {
      onSuccess: () => {
        setFormData({
          name: "",
          service: "",
          review_text: "",
          rating: 5,
        });
        toast({
          title: "¡Gracias!",
          description: "Tu reseña ha sido enviada y será revisada pronto.",
        });
      },
      onError: (error) => {
        const isRateLimit = error.message.includes('Rate limit');
        toast({
          title: "Error",
          description: isRateLimit 
            ? "Has enviado demasiadas reseñas recientemente. Por favor, espera un momento."
            : "Error al enviar la reseña. Por favor, inténtalo de nuevo.",
          variant: "destructive",
        });
      },
    });
  };

  const services = [
    "Manicura",
    "Pedicura", 
    "Manicura semipermanente",
    "Pedicura semipermanente",
    "Uñas acrílicas",
    "Nail Art",
    "Depilación de cejas",
    "Diseño de cejas"
  ];

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Deja tu reseña</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Nombre</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Tu nombre"
              required
            />
          </div>

          <div>
            <Label htmlFor="service">Servicio realizado</Label>
            <Select 
              value={formData.service} 
              onValueChange={(value) => setFormData({ ...formData, service: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecciona el servicio" />
              </SelectTrigger>
              <SelectContent>
                {services.map((service) => (
                  <SelectItem key={service} value={service}>
                    {service}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="rating">Puntuación</Label>
            <div className="flex items-center space-x-1 mt-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Button
                  key={star}
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setFormData({ ...formData, rating: star })}
                  className="p-1"
                >
                  <Star
                    className={`h-6 w-6 ${
                      star <= formData.rating
                        ? "fill-yellow-400 text-yellow-400"
                        : "text-gray-300"
                    }`}
                  />
                </Button>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="review">Tu opinión</Label>
            <Textarea
              id="review"
              value={formData.review_text}
              onChange={(e) => setFormData({ ...formData, review_text: e.target.value })}
              placeholder="Cuéntanos tu experiencia..."
              rows={4}
              required
            />
          </div>

          <Button 
            type="submit" 
            className="w-full"
            disabled={createTestimonial.isPending}
          >
            {createTestimonial.isPending ? "Enviando..." : "Enviar reseña"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};