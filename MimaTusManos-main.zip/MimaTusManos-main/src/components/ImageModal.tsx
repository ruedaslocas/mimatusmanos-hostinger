import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { X } from "lucide-react";
import { useState } from "react";

interface ImageModalProps {
  src: string;
  alt: string;
  children: React.ReactNode;
}

export const ImageModal = ({ src, alt, children }: ImageModalProps) => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-[90vw] max-h-[90vh] p-0 border-none bg-transparent">
        <div className="relative">
          <button
            onClick={() => setOpen(false)}
            className="absolute -top-10 right-0 z-50 bg-white/10 hover:bg-white/20 rounded-full p-2 text-white transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
          <img
            src={src}
            alt={alt}
            className="w-full h-full object-contain rounded-lg max-h-[85vh]"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
};