import { Phone, Mail, Instagram, MapPin, Clock } from "lucide-react";
import { useSiteContent } from "@/hooks/useSiteContent";

const Footer = () => {
  const { getContent } = useSiteContent();

  return (
    <footer className="bg-secondary py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="text-lg font-heading font-semibold">Contacto</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Phone className="h-4 w-4 text-primary" />
                <span>{getContent('telefono', '+34 622 298 109')}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Mail className="h-4 w-4 text-primary" />
                <span>{getContent('email', 'info@mimatusmanos.com')}</span>
              </div>
            </div>
          </div>

          {/* Location */}
          <div className="space-y-4">
            <h4 className="text-lg font-heading font-semibold">Ubicación</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="h-4 w-4 text-primary" />
                <span>{getContent('direccion', 'Juan De La Cosa Kalea, 6C, 48004 Bilbao, Bizkaia')}</span>
              </div>
            </div>
            
            {/* Google Maps Embed */}
            <div className="mt-4">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2904.4637734486927!2d-2.9347382846142617!3d43.268742079132245!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd4e4fdc9b1a2b9d%3A0x4f8a6e9d2b1c3e5f!2sJuan%20De%20La%20Cosa%20Kalea%2C%206C%2C%2048004%20Bilbao%2C%20Bizkaia%2C%20Spain!5e0!3m2!1sen!2ses!4v1635789012345"
                width="100%"
                height="150"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="rounded-lg"
                title="Ubicación de MimaTusManos"
              />
            </div>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h4 className="text-lg font-heading font-semibold">Servicios</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Manicura clásica</li>
              <li>Esmaltado semipermanente</li>
              <li>Uñas acrílicas/gel</li>
              <li>Nail Art personalizado</li>
              <li>Pedicura completa</li>
              <li>Diseño de cejas</li>
            </ul>
          </div>

          {/* Hours and Social */}
          <div className="space-y-4">
            <h4 className="text-lg font-heading font-semibold">Horarios</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                <span>Lun - Vie: 10:00 - 19:30</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                <span>Sáb: Cerrado</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                <span>Dom: Cerrado</span>
              </div>
            </div>
            
            <div className="pt-4">
              <h5 className="text-sm font-semibold mb-2">Síguenos</h5>
              <div className="flex space-x-4">
                <a
                  href="https://www.instagram.com/mima.tusmanoss/?hl=es"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:text-primary/80 transition-colors"
                >
                  <Instagram className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>© 2024 MimaTusManos. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;