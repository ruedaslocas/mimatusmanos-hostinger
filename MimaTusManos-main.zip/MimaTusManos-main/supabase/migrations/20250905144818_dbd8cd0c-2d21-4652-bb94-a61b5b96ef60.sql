-- Insertar datos de contacto por defecto en site_content
INSERT INTO public.site_content (content_type, content_value, description) VALUES 
('telefono', '+34 622 298 109', 'Número de teléfono principal del negocio'),
('email', 'info@mimatusmanos.com', 'Email de contacto principal'),
('direccion', 'De la Cosa Juan Kalea, 6, 48004 Bilbao, Bizkaia', 'Dirección física del negocio')
ON CONFLICT (content_type) DO UPDATE SET 
content_value = EXCLUDED.content_value,
description = EXCLUDED.description;