-- Security fix: Restrict public access to sensitive site content
-- This prevents unauthorized access to business contact information like phone and email

-- Drop the overly permissive policy that allows anyone to view all site content
DROP POLICY IF EXISTS "Anyone can view site content" ON public.site_content;

-- Create a new policy that excludes sensitive content types from public access
CREATE POLICY "Public can view non-sensitive site content" 
ON public.site_content 
FOR SELECT 
USING (
  -- Allow admins to see everything
  has_role(auth.uid(), 'admin'::app_role) OR 
  -- Allow public to see only non-sensitive content types
  (content_type NOT IN ('business_phone', 'business_email', 'contact_phone', 'contact_email', 'admin_email', 'owner_phone', 'owner_email'))
);

-- Ensure admins can still manage all site content
CREATE POLICY "Admins can manage all site content" 
ON public.site_content 
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));