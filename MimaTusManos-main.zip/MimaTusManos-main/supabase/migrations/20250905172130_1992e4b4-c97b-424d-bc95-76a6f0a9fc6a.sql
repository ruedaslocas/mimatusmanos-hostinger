-- Database optimization: Clean up and optimize indexes

-- Remove any duplicate indexes and create optimal ones
DROP INDEX IF EXISTS idx_categories_active;
DROP INDEX IF EXISTS idx_categories_display_order;
DROP INDEX IF EXISTS idx_services_active;
DROP INDEX IF EXISTS idx_services_category;
DROP INDEX IF EXISTS idx_service_prices_active;
DROP INDEX IF EXISTS idx_testimonials_approved;
DROP INDEX IF EXISTS idx_category_photos_category;

-- Create optimized composite indexes for better query performance
CREATE INDEX idx_categories_active_order ON categories(is_active, display_order) WHERE is_active = true;
CREATE INDEX idx_services_active_category_order ON services(is_active, category_id, display_order) WHERE is_active = true;
CREATE INDEX idx_service_prices_active_service ON service_prices(is_active, service_id) WHERE is_active = true;
CREATE INDEX idx_testimonials_approved_created ON testimonials(is_approved, created_at DESC) WHERE is_approved = true;
CREATE INDEX idx_category_photos_category_order ON category_photos(category_id, display_order);

-- Clean up any orphaned data
DELETE FROM service_prices WHERE service_id NOT IN (SELECT id FROM services);
DELETE FROM category_photos WHERE category_id NOT IN (SELECT id FROM categories);

-- Update statistics for better query planning
ANALYZE categories;
ANALYZE services;
ANALYZE service_prices;
ANALYZE testimonials;
ANALYZE category_photos;