-- Create category_photos table to link photos to categories
CREATE TABLE public.category_photos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category_id UUID NOT NULL REFERENCES public.categories(id) ON DELETE CASCADE,
  photo_name TEXT NOT NULL,
  photo_url TEXT NOT NULL,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.category_photos ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view category photos for active categories" 
ON public.category_photos 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.categories 
    WHERE categories.id = category_photos.category_id 
    AND (categories.is_active = true OR has_role(auth.uid(), 'admin'::app_role))
  )
);

CREATE POLICY "Only admins can manage category photos" 
ON public.category_photos 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Add trigger for automatic timestamp updates
CREATE TRIGGER update_category_photos_updated_at
BEFORE UPDATE ON public.category_photos
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create storage bucket for category photos if it doesn't exist
INSERT INTO storage.buckets (id, name, public) 
VALUES ('category-photos', 'category-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for category photos
CREATE POLICY "Category photos are publicly accessible" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'category-photos');

CREATE POLICY "Admins can upload category photos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'category-photos' AND has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update category photos" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'category-photos' AND has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete category photos" 
ON storage.objects 
FOR DELETE 
USING (bucket_id = 'category-photos' AND has_role(auth.uid(), 'admin'::app_role));