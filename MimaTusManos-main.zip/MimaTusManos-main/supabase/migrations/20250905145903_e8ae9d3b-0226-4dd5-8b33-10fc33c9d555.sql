-- Crear tabla de servicios
CREATE TABLE public.services (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  duration_minutes INTEGER,
  image_url TEXT,
  category TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Crear tabla de precios de servicios
CREATE TABLE public.service_prices (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  service_id UUID NOT NULL REFERENCES public.services(id) ON DELETE CASCADE,
  price_type TEXT NOT NULL, -- 'base', 'premium', 'deluxe', etc.
  price DECIMAL(10,2) NOT NULL,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_prices ENABLE ROW LEVEL SECURITY;

-- Políticas para servicios - todos pueden ver, solo admins pueden modificar
CREATE POLICY "Anyone can view active services" 
ON public.services 
FOR SELECT 
USING (is_active = true OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can manage services" 
ON public.services 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Políticas para precios - todos pueden ver, solo admins pueden modificar
CREATE POLICY "Anyone can view active service prices" 
ON public.service_prices 
FOR SELECT 
USING (is_active = true OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can manage service prices" 
ON public.service_prices 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Crear trigger para actualizar updated_at
CREATE TRIGGER update_services_updated_at
BEFORE UPDATE ON public.services
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_service_prices_updated_at
BEFORE UPDATE ON public.service_prices
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insertar servicios por defecto
INSERT INTO public.services (name, description, duration_minutes, category, display_order) VALUES
('Manicura Clásica', 'Tratamiento completo de manos con esmaltado tradicional', 60, 'manicura', 1),
('Manicura Semipermanente', 'Manicura con esmalte de larga duración hasta 3 semanas', 90, 'manicura', 2),
('Nail Art', 'Diseños personalizados y decoración artística en uñas', 120, 'manicura', 3),
('Pedicura Clásica', 'Tratamiento completo de pies con esmaltado tradicional', 75, 'pedicura', 4),
('Pedicura Semipermanente', 'Pedicura con esmalte de larga duración', 105, 'pedicura', 5),
('Diseño de Cejas', 'Perfilado y diseño profesional de cejas', 45, 'cejas', 6),
('Depilación con Hilo', 'Técnica precisa de depilación facial', 30, 'depilacion', 7);

-- Insertar precios por defecto
INSERT INTO public.service_prices (service_id, price_type, price, description) VALUES
((SELECT id FROM public.services WHERE name = 'Manicura Clásica'), 'base', 25.00, 'Precio estándar'),
((SELECT id FROM public.services WHERE name = 'Manicura Semipermanente'), 'base', 35.00, 'Precio estándar'),
((SELECT id FROM public.services WHERE name = 'Nail Art'), 'base', 45.00, 'Diseño básico'),
((SELECT id FROM public.services WHERE name = 'Nail Art'), 'premium', 65.00, 'Diseño avanzado'),
((SELECT id FROM public.services WHERE name = 'Pedicura Clásica'), 'base', 30.00, 'Precio estándar'),
((SELECT id FROM public.services WHERE name = 'Pedicura Semipermanente'), 'base', 40.00, 'Precio estándar'),
((SELECT id FROM public.services WHERE name = 'Diseño de Cejas'), 'base', 20.00, 'Precio estándar'),
((SELECT id FROM public.services WHERE name = 'Depilación con Hilo'), 'base', 15.00, 'Precio estándar');