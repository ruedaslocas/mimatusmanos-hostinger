-- Add featured field to category_photos table
ALTER TABLE public.category_photos 
ADD COLUMN is_featured boolean NOT NULL DEFAULT false;

-- Create index for better performance when querying featured photos
CREATE INDEX idx_category_photos_featured ON public.category_photos(is_featured, created_at DESC) WHERE is_featured = true;