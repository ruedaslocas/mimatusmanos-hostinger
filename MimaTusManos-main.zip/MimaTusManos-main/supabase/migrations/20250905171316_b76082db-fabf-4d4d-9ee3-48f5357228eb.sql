-- Fix function search path security issue
-- This ensures the function has a secure, immutable search path

DROP FUNCTION IF EXISTS check_testimonial_rate_limit();

-- Recreate the function with proper search_path setting
CREATE OR REPLACE FUNCTION public.check_testimonial_rate_limit()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
SET search_path = public
AS $$
BEGIN
  -- Allow unlimited submissions for admins
  IF has_role(auth.uid(), 'admin'::app_role) THEN
    RETURN NEW;
  END IF;
  
  -- Check if more than 3 testimonials were submitted in the last hour
  -- This prevents spam while allowing legitimate submissions
  IF (
    SELECT COUNT(*) 
    FROM public.testimonials 
    WHERE created_at > NOW() - INTERVAL '1 hour'
    AND (
      (NEW.submitted_from_ip IS NOT NULL AND submitted_from_ip = NEW.submitted_from_ip)
      OR (auth.uid() IS NOT NULL)
    )
  ) >= 3 THEN
    RAISE EXCEPTION 'Rate limit exceeded. Please wait before submitting another testimonial.';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to enforce rate limiting
CREATE TRIGGER testimonial_rate_limit_trigger
  BEFORE INSERT ON public.testimonials
  FOR EACH ROW
  EXECUTE FUNCTION public.check_testimonial_rate_limit();