-- Create categories table
CREATE TABLE public.categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view active categories" 
ON public.categories 
FOR SELECT 
USING (is_active = true OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can manage categories" 
ON public.categories 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Add trigger for automatic timestamp updates
CREATE TRIGGER update_categories_updated_at
BEFORE UPDATE ON public.categories
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default categories
INSERT INTO public.categories (name, description, display_order) VALUES
('Manicura', 'Cuidado y embellecimiento de las uñas de las manos', 1),
('Pedicura', 'Cuidado y embellecimiento de las uñas de los pies', 2),
('Depilación', 'Eliminación del vello corporal', 3),
('Cejas', 'Cuidado y diseño de las cejas', 4);

-- Add foreign key constraint to services table for category_id
ALTER TABLE public.services ADD COLUMN category_id UUID REFERENCES public.categories(id);

-- Update existing services to use the new category system (optional migration)
UPDATE public.services 
SET category_id = (
  SELECT id FROM public.categories 
  WHERE LOWER(categories.name) = LOWER(services.category)
  LIMIT 1
)
WHERE services.category IS NOT NULL;