-- Security enhancement: Add rate limiting for testimonial submissions
-- This prevents spam and abuse by limiting how frequently testimonials can be submitted

-- Add timestamp tracking for rate limiting
ALTER TABLE public.testimonials 
ADD COLUMN IF NOT EXISTS submitted_from_ip inet,
ADD COLUMN IF NOT EXISTS submission_count integer DEFAULT 1;

-- Create index for efficient rate limiting queries
CREATE INDEX IF NOT EXISTS idx_testimonials_rate_limiting 
ON public.testimonials (submitted_from_ip, created_at);

-- Add a function to check rate limits (admins bypass this)
CREATE OR REPLACE FUNCTION check_testimonial_rate_limit()
RETURNS TRIGGER AS $$
BEGIN
  -- Allow unlimited submissions for admins
  IF has_role(auth.uid(), 'admin'::app_role) THEN
    RETURN NEW;
  END IF;
  
  -- Check if more than 3 testimonials were submitted from the same source in the last hour
  IF (
    SELECT COUNT(*) 
    FROM public.testimonials 
    WHERE created_at > NOW() - INTERVAL '1 hour'
    AND (
      (NEW.submitted_from_ip IS NOT NULL AND submitted_from_ip = NEW.submitted_from_ip)
      OR (auth.uid() IS NOT NULL AND auth.uid() = auth.uid())
    )
  ) >= 3 THEN
    RAISE EXCEPTION 'Rate limit exceeded. Please wait before submitting another testimonial.';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;