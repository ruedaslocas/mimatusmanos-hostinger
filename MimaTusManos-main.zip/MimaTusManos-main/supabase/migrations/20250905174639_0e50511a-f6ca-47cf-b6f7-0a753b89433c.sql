-- Update the default logo configuration to use the new logo
UPDATE public.site_config 
SET value = '/lovable-uploads/776c3e91-a182-4a12-93fe-3e9f7ce1c8da.png'
WHERE key = 'logo_url';